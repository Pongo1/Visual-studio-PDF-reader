﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace N33mafo__PDF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

          
        }
        Point lastPoint;

        private void rectangleShape1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {


        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = e.Location;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {

                this.SetDesktopLocation(Cursor.Position.X - lastPoint.X, Cursor.Position.Y - lastPoint.Y);


            }
        }

        private void ovalShape1_MouseHover(object sender, EventArgs e)
        {
            ovalShape1.FillColor = Color.Blue;
        }

        private void ovalShape1_MouseLeave(object sender, EventArgs e)
        {
            ovalShape1.FillColor = Color.Red;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Opacity = this.Opacity + 0.005;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Opacity = this.Opacity - 0.005;
        }

        private void ovalShape1_Click(object sender, EventArgs e)
        {
          //  Application.Exit();
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //NB: ASSAN DONT READ THIS FIRST --- READ FROM THE BOTTOM UP
            //These things happen as soon as the application is launched
            /*
             Hide the 2 progressbars --obvi 
             * make the form invisible at first -- this.opacity =0;  <-- this code 
             * Now start timer2 
             * When the timer is started, a function will run in it's 'tick' event, you will see that below.
             * And then I load the prefered theme of the user set.....
             
             
             */
            progressBar2.Visible = false;
            progressBar1.Visible = false;
            groupBox1.Visible = false;
            this.Opacity = 0;
            timer2.Start();
            panel1.BackColor = Properties.Settings.Default.Theme;
           rectangleShape1.BorderColor = Properties.Settings.Default.Theme;
           rectangleShape1.FillColor = Properties.Settings.Default.Page_color;
        }

        //coming effect 

        /*
            This is the function responsible for the fadeIn effect. 
         * As soon as the app is launched, timer2 is started. 
         * Check the timer2 'tick'event, you will find this function. 
         * All the things here happens there.
         * Check the 'Form_load' event you will see timer2.start, --obvi
         */
        public void comingEffect()
        {
            progressBar2.Maximum = 100;
            progressBar2.Increment(1);
            this.Opacity = this.Opacity + 0.02;
            if (progressBar2.Value == progressBar2.Maximum)
            {
                timer2.Stop();
              
            }
        }
        //Closing effect
        /*
            This is th function that causes the fadeOut effect when the app closes.
         *  When the exit button is clicked, it will start timer1
         *  The progressbar is used here to set the limit to how long the timer should continue to count 
         *  
         */
        public void closingEffect()
        {
            progressBar1.Maximum = 50;
            progressBar1.Increment(1);
            this.Opacity = this.Opacity - 0.02;
            //As the timer is ticking and the progressbar is filling up, reduce the opacity of the form -- this then forms the nice  effect you see
            if(progressBar1.Value == progressBar1 .Maximum){
                timer1.Stop();
                Application.Exit();
            }
        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
        }

        private void rectangleShape1_MouseHover(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                axAcroPDF1.LoadFile(openFileDialog1.FileName);
                Properties.Settings.Default.Path = Path.GetDirectoryName(openFileDialog1.FileName);
                
               string[] g = System.IO.Directory.GetFiles(Path.GetDirectoryName(openFileDialog1.FileName));
                   for (int i = 0; i < g.Length; i++) {
                       
                       comboBox1.Items.Add(Path.GetFileName(g[i]));
                   }


            }
        }

        private void Form1_MouseHover(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel1.BackColor = colorDialog1.Color;
                rectangleShape1.BorderColor = colorDialog1.Color;
                Properties.Settings.Default.Theme = panel1.BackColor;
                Properties.Settings.Default.Save();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            closingEffect();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            comingEffect();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel1.BackColor = Color.DimGray;
            rectangleShape1.BorderColor = Color.Black;
            rectangleShape1.FillColor = Color.Gray;
            this.Opacity = 0.85;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (colorDialog2.ShowDialog() == DialogResult.OK)
            {

                rectangleShape1.FillColor = colorDialog2.Color;
                //Save the color that the user will choose to a settings file , for it to be read later.
                //I have set a few variables to be stored in the settings file..... 
                // go to Project->N33mafo) project->settings 
                //You will find this 'page_color'that I am storing the color the user has chosen to.
                Properties.Settings.Default.Page_color = colorDialog2.Color;
                Properties.Settings.Default.Save();
            }
            
        }

        private void ovalShape2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void ovalShape2_MouseHover(object sender, EventArgs e)
        {
            ovalShape2.FillColor = Color.DeepPink;
        }

        private void ovalShape2_MouseLeave(object sender, EventArgs e)
        {
            ovalShape2.FillColor = Color.Yellow;

        }

        private void ovalShape3_MouseHover(object sender, EventArgs e)
        {
            ovalShape3.FillColor = Color.Orange;
        }

        private void ovalShape3_MouseLeave(object sender, EventArgs e)
        {
            ovalShape3.FillColor = Color.Green;
        }

        private void ovalShape3_Click(object sender, EventArgs e)
        {

           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           string fileName =  comboBox1.SelectedItem.ToString();
            //this is how the things are loaded in the pdf file, after the combobox, reads all the items in a folder.
            //First get the path that was stored to the application's setting file and add the file name that the user has selected from the combobox
            axAcroPDF1.LoadFile(Properties.Settings .Default.Path+"\\"+fileName);
        }
    }
}
